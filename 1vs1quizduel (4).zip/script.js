const questions = [
  { q: "Wer lebt in einer Ananas ganz tief im Meer?", a: "SpongeBob" },
  { q: "Welcher Zauberer trägt eine Blitznarbe auf der Stirn?", a: "Harry Potter" },
  { q: "Was ist das größte Tier auf der Erde?", a: "Blauwal" },
  { q: "Welches Tier kann Farben wechseln?", a: "Chamäleon" },
  { q: "Was ist das Gegenteil von 'Tag'?", a: "Nacht" }
];

let current = 0;
let timerInterval;
let timeLeft = 60;

function startGame() {
  document.getElementById("game").style.display = "block";
  nextQuestion();
}

function nextQuestion() {
  if (current >= questions.length) {
    document.getElementById("question").innerText = "Spiel beendet!";
    document.getElementById("answers").innerHTML = "";
    clearInterval(timerInterval);
    return;
  }
  const q = questions[current];
  document.getElementById("question").innerText = q.q;
  document.getElementById("answers").innerHTML = '<input id="answer" placeholder="Antwort hier..."><button onclick="checkAnswer()">Antwort prüfen</button>';
  timeLeft = 60;
  document.getElementById("timer").innerText = "⏳ 60";
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    timeLeft--;
    document.getElementById("timer").innerText = "⏳ " + timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      current++;
      nextQuestion();
    }
  }, 1000);
}

function checkAnswer() {
  const input = document.getElementById("answer").value.trim().toLowerCase();
  const correct = questions[current].a.toLowerCase();
  if (input === correct) {
    alert("Richtig!");
  } else {
    alert("Falsch! Die richtige Antwort war: " + questions[current].a);
  }
  current++;
  nextQuestion();
}

function useJoker() {
  alert("Joker aktiviert! Eine falsche Antwort wird entfernt (nur symbolisch).");
}

function showHint() {
  alert("Tipp: Die Antwort beginnt mit '" + questions[current].a[0] + "'.");
}
